﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HopperLib
{
    public class Hopper : IconLib.Icon
    {
        #region Fields
        private bool _visible;
        private int _xcoord;
        private int _ycoord;
        #endregion

        #region Properties
        public bool Visible {
            get { return this._visible; }
            set {this._visible = value; }
        }
        public int Xcoord
        {
            get { return this._xcoord; }
            set { this._xcoord = value; }
        }
        public int Ycoord
        {
            get { return this._ycoord; }
            set { this._ycoord = value; }
        }
        #endregion

        #region Methods

        public override void flair()
        {
            throw new NotImplementedException();
        }

        public override void move()
        {
            throw new NotImplementedException();
        }
        public void Hop() {
            throw new NotImplementedException();
        }
        #endregion
    }
}

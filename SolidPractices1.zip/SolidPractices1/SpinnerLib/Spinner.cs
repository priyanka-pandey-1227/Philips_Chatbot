﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpinnerLib
{
    public class Spinner : IconLib.Icon
    {
        #region Fields
        private bool _clockwise;
        private int _expand;
        #endregion

        #region Properties
        public bool Clockwise
        {
            get { return this._clockwise; }
            set { this._clockwise = value; }
        }
        public int Expand
        {
            get { return this._expand; }
            set { this._expand = value; }
        }

        #endregion

        #region Methods

        public override void flair()
        {
            throw new NotImplementedException();
        }

        public override void move()
        {
            throw new NotImplementedException();
        }
        public void Spin()
        {
            throw new NotImplementedException();
        }
        #endregion
    }
}

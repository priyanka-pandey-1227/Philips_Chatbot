﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace CalculatorLib.Test
{
   // [TestClass]
    public class CalculatorUnitTest
    {
        [TestMethod]
        //BDD Naming Convention : When Then
        //Another way: Assert_Add_Success
        //Refer Book : Art of Unit Testing
        public void Given_TwoIntegers_AddInvoked_IntegerExpected()
        {
            Calculator calc = new Calculator();
            int actual_value = calc.add(20,10);
            int expected_value = 30;
            Assert.AreEqual(expected_value, actual_value);
        }

        [TestMethod]
        public void Given_TwoNegativeIntegers_AddInvoked_NegativeResultExpected()
        {
            Calculator calc = new Calculator();
            int actual_value = calc.add(-20, -10);
            int expected_value = -30;
            Assert.AreEqual(expected_value, actual_value);
        }

        [TestMethod]
        [ExpectedExceptionAttribute(typeof(DivideByZeroException))]
        public void Given_DenominatorZero_ExceptionExpected()
        {
            Calculator calc = new Calculator();
            calc.div(20, 0);
        }

    }

}

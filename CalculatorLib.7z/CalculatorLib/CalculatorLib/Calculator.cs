﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalculatorLib
{
    public class Calculator
    {
        public int add(int a, int b) {
            return a + b;
        }

        public int div(int a, int b)
        {
            return a/b;
        }
    }
}

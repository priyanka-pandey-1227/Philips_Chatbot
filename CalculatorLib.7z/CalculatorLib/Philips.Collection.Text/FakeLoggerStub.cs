﻿using LoggerContractLib;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Philips.Collection.Test
{
    public class FakeLoggerStub:ILogger
    {
        public void Write(string msg) {
           // throw new NotImplementedException();
        }
    }
}

﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Philips.Collection.Test
{
    [TestClass]
    public class ArrayListUnitTest
    {
        
        [TestMethod]
        public void GivenCollection_NewCollectionInitialized_ExpectedCountIs0()
        {
            ArrayList obj = new ArrayList();
            int actual_value = obj.Count;
            int expected_value = 0;
            Assert.AreEqual(expected_value, actual_value);
        }

        [TestMethod]
        public void Given_ArrayList_When_AddItemInvoked_Then_ExpectedValidCount()
        {
            ArrayList obj = new ArrayList();
            obj.LoggerRef = new FakeLoggerStub();
            obj.CrackEnginRef = new Moq.Mock<EncryptionAlgorithmContractLib.IEncryptAndDecrypt>().Object;
            obj.AddItem(1);
            obj.AddItem(2);
            obj.AddItem(3);
            obj.AddItem(4);

            int actual_value = obj.Count;
            int expected_value = 4;
            Assert.AreEqual(expected_value, actual_value);
        }

        [TestMethod]
        public void Given_ArrayList_When_AddItem_Invoked_Then_Expected_To_Call_EncryptMethod_AtleastOnce()
        {
            Moq.Mock<EncryptionAlgorithmContractLib.IEncryptAndDecrypt> _mockObj = new Moq.Mock<EncryptionAlgorithmContractLib.IEncryptAndDecrypt>();

            //Class under test
            Philips.Collection.ArrayList arrayList = new ArrayList();
            //Set Dependency

            EncryptionAlgorithmContractLib.IEncryptAndDecrypt neighbourRef = _mockObj.Object;
            arrayList.CrackEnginRef = neighbourRef;
            arrayList.LoggerRef = new FakeLoggerStub();
            
            //Behaviour
            arrayList.AddItem("Content");
            arrayList.AddItem("Content");
            arrayList.AddItem("NewContent");
            arrayList.AddItem("NewContent");

            //Setting the exptectation in the communication
            _mockObj.Verify(neighbour => neighbour.Encrypt("Content"),Moq.Times.Exactly(2));
            _mockObj.Verify(neighbour => neighbour.Encrypt("NewContent"), Moq.Times.Exactly(2));
            //Encrypt() contents should be same  as AddItem() content
        }
    }
}

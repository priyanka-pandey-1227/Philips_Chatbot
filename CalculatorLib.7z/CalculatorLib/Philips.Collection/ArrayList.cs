﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EncryptionAlgorithmContractLib;
using LoggerContractLib;

namespace Philips.Collection
{
    public class ArrayList{
        private LoggerContractLib.ILogger loggerRef;
        private EncryptionAlgorithmContractLib.IEncryptAndDecrypt crankEngineRef;
        private object[] items;
        int index = -1;
        private int count = 0;

        public int Count { get { return this.count; } }

        public LoggerContractLib.ILogger LoggerRef {
            get => this.loggerRef;
            set => this.loggerRef = value;
        }

       public EncryptionAlgorithmContractLib.IEncryptAndDecrypt CrackEnginRef {
            get { return this.crankEngineRef; }
            set { this.crankEngineRef = value; }
        }

        public ArrayList() {
            items = new Object[10];
        }

        public void AddItem(object item) {
            index++;
            count++;

            //Behavioral Testing: ArrayList has dependency ILogger, which is indirectly called
            this.loggerRef.Write("Add Item Called");
            if (index >= items.Length) {
                //resize
                object[] temp = new object[items.Length + 10];
                items.CopyTo(temp,0);
                items = temp;
            }
            items[index] = this.crankEngineRef.Encrypt(item);
        }

        public void Clear() {
            //this.items = new object[10];
            //Reinitialize the object and previous will be garbage collected

            this.loggerRef.Write("Items Cleared");
            for (int i = 0; i < items.Length; i++) {
                items[i] = null;
            }
            index = -1;
            count = 0;
        }
    }
}

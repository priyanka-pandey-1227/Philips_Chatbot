﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EncryptionAlgorithmContractLib;
namespace RSA
{
    public  class RsaCrankEngine: IEncryptAndDecrypt
    {
        public object Encrypt(object content)
        {
            throw new NotImplementedException();
        }

        public object Decrypt(object cipher)
        {
            throw new NotImplementedException();
        }
    }
}

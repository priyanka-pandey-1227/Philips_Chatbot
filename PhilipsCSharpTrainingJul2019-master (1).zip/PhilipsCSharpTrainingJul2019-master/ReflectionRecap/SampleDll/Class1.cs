﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SampleDll
{
    public class MathClass
    {
        public double AddFunc(double f, double s) => f + s;
    }
}

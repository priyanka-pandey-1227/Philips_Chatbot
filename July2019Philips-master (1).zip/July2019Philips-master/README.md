# July2019Philips
Effective c# Training

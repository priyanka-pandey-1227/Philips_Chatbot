﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SliderLib
{
    public class Slider : IconLib.Icon
    {
        #region Fields
        private bool _verticle;
        private int _distance;
        #endregion

        #region Properties
        public bool Vertical
        {
            get { return this._verticle; }
            set { this._verticle = value; }
        }
        public int Distance
        {
            get { return this._distance; }
            set { this._distance = value; }
        }
        #endregion

        #region Methods

        public override void flair()
        {
            throw new NotImplementedException();
        }

        public override void move()
        {
            throw new NotImplementedException();
        }
        public void Slide()
        {
            throw new NotImplementedException();
        }
        #endregion
    }
}

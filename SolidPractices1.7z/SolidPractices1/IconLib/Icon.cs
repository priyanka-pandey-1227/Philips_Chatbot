﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IconLib
{
    public abstract class Icon
    {
        #region Properties
        public double speed { get; set; }
        public double glow { get; set; }
        public double energy { get; set; }
        public int x { get; set; }
        public int y { get; set; }
        public int subtype { get; set; }
        #endregion

        #region Subtypes
        public enum Subtypes
        {
            Spin, Slide, Hop
        }
        #endregion

        #region Methods
        public abstract void move();
        /* {
            throw new NotImplementedException();
          switch (type)
            {
                case Subtypes.Spin:
                    spin();
                    break;
                case Subtypes.Slide:
                    slide();
                    break;
                default:
                    hop();
                    break;
            }
            
        }*/

        public abstract void flair();
        /*{
            switch (type)
            {
                case Subtypes.Spin:
                    spin();
                    break;
                case Subtypes.Slide:
                    slide();
                    break;
                default:
                    hop();
                    break;
            }
            
            throw new NotImplementedException();
        }*/

        #endregion
    }
}

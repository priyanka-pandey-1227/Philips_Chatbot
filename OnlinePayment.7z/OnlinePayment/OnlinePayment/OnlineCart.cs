﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gateaway
{
    public class OnlineCart
    {
        private PaymentContractLib.IProcessPayment _processPayment;

        public OnlineCart(PaymentContractLib.IProcessPayment processPayment)
        {
            this._processPayment = processPayment;
        }

        public void CheckOut()
        {
            _processPayment.ProcessPayment();
        }
    }
}

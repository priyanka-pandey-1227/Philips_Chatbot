﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CreditCardPaymentLib
{
    public  class ProcessPaypalPayment : PaymentContractLib.IProcessPayment
    {
        public void ProcessPayment() {
            throw new NotImplementedException();
        }
    }
}

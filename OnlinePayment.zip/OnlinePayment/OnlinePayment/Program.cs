﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnlinePayment
{
    class Program
    {
        static void Main(string[] args)
        {
            PaymentContractLib.IProcessPayment payment = new CreditCardPaymentLib.ProcessCreditCardPayment();
            OnlineCart cart = new OnlineCart(payment);
            cart.CheckOut();
        }
    }
}

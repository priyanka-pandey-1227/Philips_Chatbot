﻿namespace HttpConsoleApp
{
    public partial class OptionTable
    {
        public int option_id { get; set; }
        public int question_id { get; set; }
        public int link_id { get; set; }
    }
}

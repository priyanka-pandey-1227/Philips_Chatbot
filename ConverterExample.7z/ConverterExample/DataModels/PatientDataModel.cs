﻿namespace DataModels
{
    public class PatientDataModel
    {
        public string PatientId { get; set; }
        public string PatientName { get; set; }
        public int Spo2 { get; set; }
        public int PulseRate { get; set; }
        public decimal Temperature { get; set; }
    }
}

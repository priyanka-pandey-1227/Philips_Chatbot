﻿using DataReaders;
using DataWriters;

namespace DataConverters
{
    class DemoClass
    {
        static void Main()
        {
            string source = "PatientData.csv";
            string destination = "PatientData.xml";

            var reader = new CsvPatientDataReader(source);
            var writer = new XmlPatientDataWriter(destination);

            PatientDataTransformer dataTransformer = new PatientDataTransformer(reader, writer);

            dataTransformer.Transform();
        }
    }
}

﻿using DataReaders;
using DataWriters;

namespace DataConverters
{
    class PatientDataTransformer
    {
        private IPatientDataReader _reader;
        private IPatientDataWriter _writer;

        public PatientDataTransformer(IPatientDataReader reader, IPatientDataWriter writer)
        {
            _reader = reader;
            _writer = writer;
        }

        public IPatientDataReader Reader
        {
            get { return _reader; }
            set { _reader = value; }
        }

        public IPatientDataWriter Writer
        {
            get { return _writer; }
            set { _writer = value; }
        }
        
        public bool Transform()
        {
            var records = _reader.GetRecords();
            _writer.WriteRecords(records);
            return true;
        }
    }
}

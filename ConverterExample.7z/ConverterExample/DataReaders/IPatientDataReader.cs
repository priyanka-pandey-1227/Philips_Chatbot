﻿using System.Collections.Generic;
using DataModels;

namespace DataReaders
{
    public interface IPatientDataReader
    {
        List<PatientDataModel> GetRecords();
    }
}
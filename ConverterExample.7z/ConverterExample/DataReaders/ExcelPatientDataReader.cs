﻿using DataModels;
using System;
using System.Collections.Generic;

namespace DataReaders
{
    class ExcelPatientDataReader : IPatientDataReader
    {
        public List<PatientDataModel> GetRecords()
        {
            throw new NotImplementedException();
        }
    }
}

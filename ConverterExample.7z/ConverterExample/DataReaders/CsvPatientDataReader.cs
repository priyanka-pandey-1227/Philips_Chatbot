﻿using DataModels;
using System;
using System.Collections.Generic;
using System.IO;

namespace DataReaders
{
    public class CsvPatientDataReader : IPatientDataReader
    {
        private readonly string _filePath;

        public CsvPatientDataReader(string filePath)
        {
            _filePath = filePath;
        }

        public List<PatientDataModel> GetRecords()
        {
            List<PatientDataModel> records = new List<PatientDataModel>();
            using (StreamReader reader = new StreamReader(_filePath))
            {
                while (!reader.EndOfStream)
                {
                    var line = reader.ReadLine();
                    var record = line.Split(',');
                    PatientDataModel modelRecord = new PatientDataModel();
                    modelRecord.PatientId = record[0].ToString();
                    modelRecord.PatientName = record[1].ToString();
                    modelRecord.Spo2 = Convert.ToInt32(record[2]);
                    modelRecord.PulseRate = Convert.ToInt32(record[3]);
                    modelRecord.Temperature = Convert.ToDecimal(record[4]);
                    records.Add(modelRecord);
                }
            }
            return records;
        }
    }
}

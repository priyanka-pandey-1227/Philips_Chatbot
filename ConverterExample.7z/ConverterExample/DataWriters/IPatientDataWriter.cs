﻿using System.Collections.Generic;
using DataModels;

namespace DataWriters
{
    public interface IPatientDataWriter
    {
        bool WriteRecords(List<PatientDataModel> records);
    }
}
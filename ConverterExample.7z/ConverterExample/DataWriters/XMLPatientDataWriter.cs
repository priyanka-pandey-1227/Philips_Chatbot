﻿using DataModels;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;

namespace DataWriters
{
    public class XmlPatientDataWriter : IPatientDataWriter
    {
        private readonly string _filePath;

        public XmlPatientDataWriter(string filePath)
        {
            _filePath = filePath;
        }

        public bool WriteRecords(List<PatientDataModel> records)
        {
            var xmlRecords = new XElement("PatientRecords",
                from record in records
                select new XElement("Patient",
                    new XAttribute("Id", record.PatientId),
                    new XAttribute("Name", record.PatientName),
                    new XAttribute("Spo2", record.Spo2),
                    new XAttribute("PulseRate", record.PulseRate),
                    new XAttribute("Temperature", record.Temperature)));
            xmlRecords.Save(_filePath);
            return true;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ViewModelsLib
{
    public class CommentsViewModel
    {
        private bool _status;   //status field: camel case
        public bool Status  //Status property: pascal case
        {
            //Definition
            get { return this._status;  }
            set { this._status = value; }
        }
        public void Save()
        {
        }
    }
}

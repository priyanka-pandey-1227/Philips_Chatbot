﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace CommandPatternExample
{
    public class ViewModel
    {
        #region Initializers
        public ViewModel() {
            Action<object> executeFunObj = new Action<object>(this.onSaveCommandExecute);
            Func<object, bool> canExecuteFunObj = new Func<object, bool>(this.onSaveCommandCanExecute);
            SaveCommand = new DelegateCommand(executeFunObj, canExecuteFunObj);

            /*To Remove Wrapper methods
             * Action<object> executeFunObj = (object obj)=>{this.Save();};
            
             * To Remove Function Objects too
             * SaveCommand=new DelegateCommand((object obj)=>{this.Save;},(object obj)=>{return true;})
             * */

            Action<object> executeDelFunObj = new Action<object>(this.onDeleteCommandExecute);
            Func<object, bool> canExecuteDelFunObj = new Func<object, bool>(this.onDeleteCommandCanExecute);
            deleteCommand = new DelegateCommand(executeDelFunObj, canExecuteDelFunObj);
        }
        #endregion

        #region Commands
        private ICommand _saveCommand;
        private ICommand _deleteCommand;
        public ICommand SaveCommand { get; set; }
        public ICommand deleteCommand { get; set; }
        #endregion

        #region CommandHelpers/ViewLogicCommandWrappers
        public void onSaveCommandExecute(object parameter) {
            this.Save();
        }
        public bool onSaveCommandCanExecute(object parameter)
        {
            return true;
        }

        public void onDeleteCommandExecute(object parameter) {
            this.Delete();
         }
        public bool onDeleteCommandCanExecute(object parameter) {
            return true;
        }
        #endregion

        #region ViewLogic
        public void Save() {
        }
        public void Delete() {
        }
        #endregion
    }
}

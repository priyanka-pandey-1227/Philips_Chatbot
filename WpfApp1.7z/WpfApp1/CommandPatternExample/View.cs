﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommandPatternExample
{
    class View
    {
        ViewModel viewModelRef = new ViewModel();
        public void buttonClick() {
            if (this.viewModelRef.SaveCommand.CanExecute(null)) {
               this.viewModelRef.SaveCommand.Execute(null);
            }
        }

        public void DeleteButtonClick() {
            if (this.viewModelRef.deleteCommand.CanExecute(null)) {
                this.viewModelRef.deleteCommand.Execute(null);
            }
        }
    }
}

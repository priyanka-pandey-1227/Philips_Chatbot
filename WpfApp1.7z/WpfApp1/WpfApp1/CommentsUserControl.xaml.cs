﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfAppDemo
{
    //ViewModel Reference

    public partial class CommentsUserControl : UserControl
    {
        ViewModelsLib.CommentsViewModel _viewModelRef;
        public CommentsUserControl()
        {
            InitializeComponent();
            _viewModelRef = new ViewModelsLib.CommentsViewModel();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            //this._viewModelRef.Save();    //Never directly call a method, put it in commands i.e. View->Command->ViewModel
            

        }
    }
}

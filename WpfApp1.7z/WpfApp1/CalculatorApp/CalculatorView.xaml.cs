﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using CalculatorModuleLib;
namespace CalculatorApp
{
    /// <summary>
    /// Interaction logic for CalculatorView.xaml
    /// </summary>
    /// 
    public partial class CalculatorView : Window
    {
        CalculatorViewModel calcVmRef = new CalculatorViewModel();
        public CalculatorView()
        {
            InitializeComponent();
           // this.DataContext = calcVmRef;   //Setting the DataContextProperty of Window and all the children will inherit it.
            //this.addButton.Command = calcVmRef.AddCommand;
            //this.subButton.Command = calcVmRef.SubCommand;
            //this.mulButton.Command = calcVmRef.MulCommand;
            //this.divButton.Command = calcVmRef.DivCommand;

            /*
            //Binding
            Binding _connector_operandOne = new Binding();
            _connector_operandOne.Source = calcVmRef;   //source  Object
            _connector_operandOne.Path = new PropertyPath("OperandOne");    //Source Property
            _connector_operandOne.Mode = BindingMode.OneWayToSource;    //Mode
            this.OperandOneTextBox.SetBinding(TextBox.TextProperty, _connector_operandOne);  //Set Target Propery

            Binding _connector_operandTwo = new Binding();
            _connector_operandTwo.Source = calcVmRef;
            _connector_operandTwo.Path = new PropertyPath("OperandTwo");
            _connector_operandTwo.Mode = BindingMode.OneWayToSource;
            this.OperandTwoTextBox.SetBinding(TextBox.TextProperty, _connector_operandTwo);

            Binding _connector_result = new Binding();
            _connector_result.Source = calcVmRef;
            _connector_result.Path = new PropertyPath("Result");
            _connector_result.Mode = BindingMode.OneWay;
            this.Result.SetBinding(TextBox.TextProperty, _connector_result);

            //The same code for Result can be written in XAML as
             //<TextBox Text="{Binding Source=_calcVmRef, Path=Result, Mode=OneWay}" />

            */

        }


    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using MVVMUtilityLib;

namespace CalculatorModuleLib
{
    public class CalculatorViewModel:System.ComponentModel.INotifyPropertyChanged
    {
        public CalculatorViewModel()
        {
            #region Initializers
            AddCommand = new DelegateCommand((object obj) => { this.Add(); }, (object obj) => { return true; });
            SubCommand = new DelegateCommand((object obj) => { this.Add(); }, (object obj) => { return true; });
            MulCommand = new DelegateCommand((object obj) => { this.Add(); }, (object obj) => { return true; });
            DivCommand = new DelegateCommand((object obj) => { this.Add(); }, (object obj) => { return true; });
            #endregion
        }
        #region Commands
    public ICommand AddCommand { get; set; }
    public ICommand SubCommand { get; set; }
    public ICommand MulCommand { get; set; }
    public ICommand DivCommand { get; set; }
        #endregion

        #region DataMembers
        private int _operandOne, _operandTwo,_result;

        #endregion
        #region Data Properties
        public int OperandOne { get { return this._operandOne; } set => this._operandOne = value; }
        public int OperandTwo { get { return this._operandTwo; } set => this._operandTwo = value; }
        public int Result
        {
            get { return this._result; }
            set {
                if(value!=this._result)
                this._result = value;
                OnPropertyChanged("Result");
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        #endregion

        #region Behaviours
        void OnPropertyChanged(string propertyName) {
            if (PropertyChanged != null) {
                PropertyChanged.Invoke(this, new PropertyChangedEventArgs(propertyName));
            }
        }
        #endregion

        #region ViewLogic
        public void Add()
        {
            //this._result=_operandOne+_operandTwo;     Never set directly private fields
            this.Result = this.OperandOne + this.OperandTwo;
        }
        public void Sub()
        {
        }
        public void Mul()
        {
        }
        public void Div()
        {
        }
        #endregion
    }
}
